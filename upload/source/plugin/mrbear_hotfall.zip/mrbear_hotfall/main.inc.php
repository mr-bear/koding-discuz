<?php
/**
 * Created by PhpStorm.
 * User: xiongfei
 * Date: 14-8-29
 * Time: 下午5:28
 */


if (!defined('IN_DISCUZ')) {

    exit('Access Denied');

}

include_once template('mrbear_hotfall:main');